const express=require('express')
const route=express.Router()
const services = require('../services/render');
const controller=require('../controller/controller');

route.get('/', services.homeRoutes);

route.get('/home', services.home)

route.get('/add-book', services.add_book)
route.get('/book', services.index)

route.get('/update-book', services.update_book)
route.get('/about', services.about)

route.post('/search',services.searchRoute)



route.post('/checkAdmin',controller.check)


route.post('/api/users', controller.create);
route.get('/api/users', controller.find);
route.put('/api/users/:id', controller.update);
route.delete('/api/users/:id', controller.delete);

route.post('/api/search',controller.searchBooks)


module.exports=route